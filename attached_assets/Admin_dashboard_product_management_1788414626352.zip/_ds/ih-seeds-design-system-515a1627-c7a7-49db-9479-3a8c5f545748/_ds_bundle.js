/* @ds-bundle: {"format":4,"namespace":"IHSeedsDesignSystem_515a16","components":[{"name":"ArticleCard","sourcePath":"components/content/ArticleCard.jsx"},{"name":"CtaBanner","sourcePath":"components/content/CtaBanner.jsx"},{"name":"FeaturePanel","sourcePath":"components/content/FeaturePanel.jsx"},{"name":"HeroBanner","sourcePath":"components/content/HeroBanner.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"NewsletterSignup","sourcePath":"components/forms/NewsletterSignup.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Icon","sourcePath":"components/icons/Icon.jsx"},{"name":"SiteFooter","sourcePath":"components/navigation/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"components/navigation/SiteHeader.jsx"},{"name":"ProductCard","sourcePath":"components/product/ProductCard.jsx"},{"name":"QuickFacts","sourcePath":"components/product/QuickFacts.jsx"},{"name":"StockPill","sourcePath":"components/product/StockPill.jsx"}],"sourceHashes":{"components/content/ArticleCard.jsx":"6d0a95c73d49","components/content/CtaBanner.jsx":"5289f7ff89aa","components/content/FeaturePanel.jsx":"2f793bb91767","components/content/HeroBanner.jsx":"c500011f3b7b","components/core/Badge.jsx":"fe6ac3e1312a","components/core/Button.jsx":"638a96e74bd1","components/core/Card.jsx":"7eabef3cf9c4","components/core/IconButton.jsx":"be0c283ba361","components/core/SectionHeading.jsx":"f420841dd26c","components/forms/Checkbox.jsx":"6a30a8ce4a8a","components/forms/Input.jsx":"590c3036b7f9","components/forms/NewsletterSignup.jsx":"3de092841909","components/forms/Select.jsx":"7da34f7d9fce","components/icons/Icon.jsx":"a832f984c77f","components/navigation/SiteFooter.jsx":"531b9862f661","components/navigation/SiteHeader.jsx":"bd4037e8f718","components/product/ProductCard.jsx":"4ee348050e81","components/product/QuickFacts.jsx":"25f18c06d9dc","components/product/StockPill.jsx":"c6fa12a634cf","ui_kits/website/AboutScreen.jsx":"a04bece6e7fe","ui_kits/website/HomeScreen.jsx":"c1a73fbbf180","ui_kits/website/ProductScreen.jsx":"f8380ad55d13","ui_kits/website/ProductsScreen.jsx":"c202bdd50bad","ui_kits/website/ResourcesScreen.jsx":"ed8f2fbbb1c7","ui_kits/website/Shell.jsx":"73d22d658f3a","ui_kits/website/data.js":"bb5929d8943f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.IHSeedsDesignSystem_515a16 = window.IHSeedsDesignSystem_515a16 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/HeroBanner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Full-bleed photographic hero. Line one light, line two bold, both white,
 * over a paddock photograph with a dark scrim.
 */
function HeroBanner({
  lineOne,
  lineTwo,
  lead,
  image,
  actions,
  height = 720,
  align = 'center',
  overlay,
  children,
  style,
  ...rest
}) {
  const centred = align === 'center';
  return /*#__PURE__*/React.createElement("section", _extends({}, rest, {
    style: {
      position: 'relative',
      minHeight: height,
      display: 'flex',
      alignItems: 'center',
      justifyContent: centred ? 'center' : 'flex-start',
      overflow: 'hidden',
      background: 'var(--surface-inverse-deep)',
      ...style
    }
  }), image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: overlay || 'var(--scrim-hero)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      width: '100%',
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--space-24) var(--space-8)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: centred ? 'center' : 'flex-start',
      textAlign: centred ? 'center' : 'left',
      gap: 'var(--space-6)'
    }
  }, children, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      color: 'var(--white)',
      fontSize: 'var(--fs-display)',
      lineHeight: 'var(--lh-display)',
      letterSpacing: 'var(--ls-display)',
      fontWeight: 'var(--fw-light)'
    }
  }, lineOne, lineTwo ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 'var(--fw-bold)'
    }
  }, lineTwo)) : null), lead ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--white)',
      fontSize: 'var(--fs-lead)',
      lineHeight: 'var(--lh-lead)',
      maxWidth: 'var(--measure-lead)'
    }
  }, lead) : null, actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      flexWrap: 'wrap',
      justifyContent: centred ? 'center' : 'flex-start',
      marginTop: 'var(--space-2)'
    }
  }, actions) : null));
}
Object.assign(__ds_scope, { HeroBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/HeroBanner.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  accent: {
    bg: 'var(--yellow-900)',
    fg: 'var(--ih-green)',
    border: 'transparent'
  },
  green: {
    bg: 'var(--ih-green)',
    fg: 'var(--white)',
    border: 'transparent'
  },
  soft: {
    bg: 'var(--green-050)',
    fg: 'var(--ih-green)',
    border: 'transparent'
  },
  cream: {
    bg: 'var(--yellow-200)',
    fg: 'var(--neutral-900)',
    border: 'transparent'
  },
  outline: {
    bg: 'transparent',
    fg: 'var(--ih-green)',
    border: 'var(--border-default)'
  },
  dark: {
    bg: 'var(--neutral-900)',
    fg: 'var(--white)',
    border: 'transparent'
  }
};
function Badge({
  children,
  tone = 'accent',
  uppercase = true,
  size = 'md',
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.accent;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: sm ? '4px 10px' : '7px 16px',
      borderRadius: 'var(--radius-badge)',
      border: `1px solid ${t.border}`,
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: sm ? '0.6875rem' : 'var(--fs-eyebrow)',
      lineHeight: 1.2,
      letterSpacing: uppercase ? 'var(--ls-eyebrow)' : 0,
      textTransform: uppercase ? 'uppercase' : 'none',
      whiteSpace: 'nowrap',
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/content/ArticleCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ArticleCard({
  title,
  date,
  excerpt,
  image,
  category = 'Editorial',
  href,
  onClick,
  imageHeight = 260,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: onClick,
    style: {
      position: 'relative',
      display: 'block',
      overflow: 'hidden',
      borderRadius: 'var(--radius-image)',
      height: imageHeight,
      background: 'var(--green-050)',
      boxShadow: 'var(--shadow-image)'
    }
  }, image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      transform: hover ? 'scale(1.04)' : 'scale(1)',
      transition: 'transform var(--dur-image) var(--ease-standard)'
    }
  }) : null, category ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 'var(--space-5)',
      left: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "accent"
  }, category)) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, date ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 'var(--fs-small)',
      color: 'var(--ih-green)'
    }
  }, date) : null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-h3)',
      lineHeight: 1.25,
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-heading)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: onClick,
    style: {
      color: 'inherit',
      textDecoration: 'none'
    }
  }, title)), excerpt ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-body)',
      maxWidth: '38ch'
    }
  }, excerpt) : null));
}
Object.assign(__ds_scope, { ArticleCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ArticleCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANTS = {
  primary: {
    bg: 'var(--btn-primary-bg)',
    fg: 'var(--btn-primary-fg)',
    border: 'transparent',
    hoverBg: 'var(--btn-primary-bg-hover)',
    activeBg: 'var(--btn-primary-bg-active)',
    hoverFg: 'var(--btn-primary-fg)'
  },
  accent: {
    bg: 'var(--btn-accent-bg)',
    fg: 'var(--btn-accent-fg)',
    border: 'transparent',
    hoverBg: 'var(--btn-accent-bg-hover)',
    activeBg: 'var(--btn-accent-bg-active)',
    hoverFg: 'var(--btn-accent-fg)'
  },
  secondary: {
    bg: 'var(--btn-secondary-bg)',
    fg: 'var(--btn-secondary-fg)',
    border: 'transparent',
    hoverBg: 'var(--btn-secondary-bg-hover)',
    activeBg: 'var(--btn-secondary-bg-active)',
    hoverFg: 'var(--btn-secondary-fg)'
  },
  outline: {
    bg: 'transparent',
    fg: 'var(--btn-outline-fg)',
    border: 'var(--btn-outline-border)',
    hoverBg: 'var(--btn-outline-bg-hover)',
    activeBg: 'var(--green-200)',
    hoverFg: 'var(--btn-outline-fg)'
  },
  onImage: {
    bg: 'var(--white)',
    fg: 'var(--btn-outline-fg)',
    border: 'var(--white)',
    hoverBg: 'var(--yellow-050)',
    activeBg: 'var(--green-050)',
    hoverFg: 'var(--btn-outline-fg)'
  },
  ghost: {
    bg: 'transparent',
    fg: 'var(--btn-outline-fg)',
    border: 'transparent',
    hoverBg: 'var(--green-050)',
    activeBg: 'var(--green-200)',
    hoverFg: 'var(--btn-primary-bg-hover)'
  }
};
const SIZES = {
  sm: {
    padding: '9px 20px',
    fontSize: '0.875rem',
    minHeight: 38
  },
  md: {
    padding: '13px 30px',
    fontSize: '1rem',
    minHeight: 48
  },
  lg: {
    padding: '17px 38px',
    fontSize: '1.125rem',
    minHeight: 58
  }
};
function Button({
  children,
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  as = 'button',
  href,
  onClick,
  style,
  ...rest
}) {
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = SIZES[size] || SIZES.md;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const Tag = href ? 'a' : as;
  const bg = disabled ? 'var(--neutral-050)' : active ? v.activeBg : hover ? v.hoverBg : v.bg;
  const fg = disabled ? 'var(--neutral-500)' : hover ? v.hoverFg : v.fg;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    onClick: disabled ? undefined : onClick,
    "aria-disabled": disabled || undefined,
    disabled: Tag === 'button' ? disabled : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false)
  }, rest, {
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: 'var(--space-2)',
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: s.fontSize,
      lineHeight: 1.15,
      letterSpacing: 0,
      padding: s.padding,
      minHeight: s.minHeight,
      borderRadius: 'var(--radius-pill)',
      border: `2px solid ${disabled ? 'transparent' : v.border}`,
      background: bg,
      color: fg,
      textDecoration: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transform: active && !disabled ? 'translateY(1px)' : 'none',
      transition: 'var(--transition-interactive)',
      whiteSpace: 'nowrap',
      ...style
    }
  }), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/content/CtaBanner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Inset, rounded, full-width photographic call-to-action band.
 */
function CtaBanner({
  headline,
  image,
  cta,
  ctaHref,
  onCtaClick,
  tone = 'image',
  height = 620,
  style,
  ...rest
}) {
  const isImage = tone === 'image';
  return /*#__PURE__*/React.createElement("section", _extends({}, rest, {
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: 'var(--radius-image)',
      minHeight: height,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: isImage ? 'var(--surface-inverse-deep)' : 'var(--surface-inverse)',
      ...style
    }
  }), isImage && image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : null, isImage ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(180deg,rgba(29,40,28,.42),rgba(29,40,28,.52))'
    }
  }) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      textAlign: 'center',
      padding: 'var(--space-16) var(--space-8)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 'var(--space-10)',
      maxWidth: 1000
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      color: 'var(--white)',
      fontWeight: 'var(--fw-light)',
      fontSize: 'clamp(2rem,3.6vw,3.25rem)',
      lineHeight: 1.2,
      letterSpacing: 'var(--ls-heading)'
    }
  }, headline), cta ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "accent",
    size: "lg",
    href: ctaHref,
    onClick: onCtaClick
  }, cta) : null));
}
Object.assign(__ds_scope, { CtaBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/CtaBanner.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  plain: {
    bg: 'transparent',
    fg: 'var(--text-body)',
    border: 'transparent',
    shadow: 'none'
  },
  white: {
    bg: 'var(--surface-card)',
    fg: 'var(--text-body)',
    border: 'var(--border-subtle)',
    shadow: 'var(--shadow-card)'
  },
  subtle: {
    bg: 'var(--surface-subtle)',
    fg: 'var(--text-body)',
    border: 'transparent',
    shadow: 'none'
  },
  cream: {
    bg: 'var(--surface-cream)',
    fg: 'var(--text-body)',
    border: 'var(--yellow-200)',
    shadow: 'none'
  },
  green: {
    bg: 'var(--surface-inverse)',
    fg: 'var(--text-on-dark)',
    border: 'transparent',
    shadow: 'none'
  },
  accent: {
    bg: 'var(--surface-accent)',
    fg: 'var(--ih-green)',
    border: 'transparent',
    shadow: 'none'
  }
};
function Card({
  children,
  tone = 'white',
  padding = 'md',
  radius = 'card',
  interactive = false,
  as = 'div',
  href,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.white;
  const [hover, setHover] = React.useState(false);
  const pad = {
    none: 0,
    sm: 'var(--space-5)',
    md: 'var(--space-8)',
    lg: 'var(--space-12)'
  }[padding];
  const Tag = href ? 'a' : as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest, {
    style: {
      display: 'block',
      background: t.bg,
      color: t.fg,
      border: `1px solid ${t.border}`,
      borderRadius: radius === 'panel' ? 'var(--radius-panel)' : radius === 'sm' ? 'var(--radius-sm)' : 'var(--radius-card)',
      padding: pad,
      textDecoration: 'none',
      boxShadow: interactive && hover ? 'var(--shadow-card-hover)' : t.shadow,
      transform: interactive && hover ? 'translateY(-2px)' : 'none',
      transition: 'var(--transition-interactive)',
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The IH Seeds signature two-weight heading: light first word(s), bold last word(s).
 * "Best **Sellers**", "Tips & **Advice**", "About **Us**".
 */
function SectionHeading({
  light,
  bold,
  as = 'h2',
  align = 'left',
  tone = 'green',
  size = 'md',
  actions,
  style,
  ...rest
}) {
  const Tag = as;
  const color = tone === 'onDark' ? 'var(--white)' : 'var(--text-heading)';
  const fs = size === 'lg' ? 'clamp(2.5rem,4.4vw,3.75rem)' : size === 'sm' ? 'var(--fs-h3)' : 'var(--fs-h2)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)',
      justifyContent: align === 'center' ? 'center' : 'space-between',
      marginBottom: 'var(--space-10)',
      ...style
    }
  }), /*#__PURE__*/React.createElement(Tag, {
    style: {
      margin: 0,
      color,
      fontSize: fs,
      lineHeight: 1.15,
      letterSpacing: 'var(--ls-heading)',
      fontWeight: 'var(--fw-light)',
      textAlign: align
    }
  }, light, bold ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: '0.28em'
    }
  }), /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 'var(--fw-bold)'
    }
  }, bold)) : null), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      flex: '0 0 auto'
    }
  }, actions) : null);
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/content/FeaturePanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Split feature block: rounded photograph one side, solid green panel with copy the other.
 * The "About Us" section of the IH Seeds homepage.
 */
function FeaturePanel({
  light,
  bold,
  body,
  image,
  imageAlt = '',
  cta,
  ctaHref,
  onCtaClick,
  imageSide = 'left',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,minmax(0,1fr))',
      gap: 'var(--space-8)',
      alignItems: 'stretch',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      order: imageSide === 'left' ? 0 : 1,
      borderRadius: 'var(--radius-panel)',
      overflow: 'hidden',
      background: 'var(--green-050)',
      minHeight: 420
    }
  }, image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: imageAlt,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      order: imageSide === 'left' ? 1 : 0,
      background: 'var(--surface-inverse)',
      borderRadius: 'var(--radius-panel)',
      padding: 'clamp(var(--space-8),4vw,var(--space-16))',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SectionHeading, {
    light: light,
    bold: bold,
    tone: "onDark",
    style: {
      marginBottom: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--white)',
      fontSize: 'var(--fs-h6)',
      lineHeight: 1.8,
      maxWidth: '46ch',
      marginBottom: 'var(--space-8)'
    }
  }, body), cta ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "accent",
    href: ctaHref,
    onClick: onCtaClick
  }, cta)) : null));
}
Object.assign(__ds_scope, { FeaturePanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/FeaturePanel.jsx", error: String((e && e.message) || e) }); }

// components/icons/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CDN = 'https://cdn.jsdelivr.net/npm/lucide-static@0.469.0/icons/';
const cache = new Map();
function load(name) {
  if (!cache.has(name)) {
    cache.set(name, fetch(CDN + name + '.svg').then(r => r.ok ? r.text() : '').then(svg => svg.replace(/\swidth="[^"]*"/, '').replace(/\sheight="[^"]*"/, '').replace(/stroke="[^"]*"/g, 'stroke="currentColor"').replace('<svg', '<svg width="100%" height="100%"')).catch(() => ''));
  }
  return cache.get(name);
}

/**
 * Recolourable icon backed by the Lucide static SVG CDN.
 * The SVG markup is fetched once per glyph and inlined so it inherits currentColor.
 * IH Seeds ships no icon set of its own — see readme.md ICONOGRAPHY.
 */
function Icon({
  name,
  size = 20,
  strokeWidth,
  color,
  style,
  ...rest
}) {
  const [svg, setSvg] = React.useState(() => cache.has(name) && cache.get(name).__value || '');
  React.useEffect(() => {
    let live = true;
    load(name).then(s => {
      if (live) setSvg(s);
    });
    return () => {
      live = false;
    };
  }, [name]);
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true"
  }, rest, {
    dangerouslySetInnerHTML: {
      __html: svg
    },
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      flex: '0 0 auto',
      color: color || 'currentColor',
      strokeWidth: strokeWidth,
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANTS = {
  accent: {
    bg: 'var(--yellow-900)',
    fg: 'var(--ih-green)',
    border: 'transparent',
    hoverBg: 'var(--yellow-500)',
    activeBg: 'var(--btn-accent-bg-active)'
  },
  outline: {
    bg: 'transparent',
    fg: 'var(--ih-green)',
    border: 'var(--ih-green)',
    hoverBg: 'var(--green-050)',
    activeBg: 'var(--green-200)'
  },
  onDark: {
    bg: 'var(--white)',
    fg: 'var(--ih-green)',
    border: 'transparent',
    hoverBg: 'var(--yellow-050)',
    activeBg: 'var(--green-050)'
  },
  quiet: {
    bg: 'transparent',
    fg: 'var(--white)',
    border: 'transparent',
    hoverBg: 'rgba(255,255,255,.16)',
    activeBg: 'rgba(255,255,255,.26)'
  }
};
const SIZES = {
  sm: 34,
  md: 44,
  lg: 52
};
function IconButton({
  icon = 'arrow-right',
  label,
  variant = 'accent',
  size = 'md',
  disabled = false,
  onClick,
  href,
  style,
  ...rest
}) {
  const v = VARIANTS[variant] || VARIANTS.accent;
  const px = SIZES[size] || SIZES.md;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    "aria-label": label,
    onClick: disabled ? undefined : onClick,
    disabled: Tag === 'button' ? disabled : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false)
  }, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: px,
      height: px,
      borderRadius: 'var(--radius-pill)',
      border: `1.5px solid ${v.border}`,
      background: disabled ? 'var(--neutral-050)' : active ? v.activeBg : hover ? v.hoverBg : v.bg,
      color: disabled ? 'var(--neutral-200)' : v.fg,
      opacity: disabled ? 0.65 : 1,
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-interactive)',
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: Math.round(px * 0.42)
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  count,
  checked = false,
  onChange,
  disabled = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      padding: '6px 0',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange
  }, rest, {
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 22,
      height: 22,
      flex: '0 0 auto',
      borderRadius: 'var(--radius-xs)',
      border: `1.5px solid ${checked ? 'var(--ih-green)' : hover ? 'var(--border-strong)' : 'var(--border-default)'}`,
      background: checked ? 'var(--ih-green)' : 'var(--white)',
      transition: 'var(--transition-interactive)'
    }
  }, checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 15,
    color: "var(--white)"
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, label), count != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 'var(--fs-small)'
    }
  }, count) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  iconLeft,
  id,
  tone = 'default',
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || `ih-input-${React.useId()}`;
  const onDark = tone === 'onDark';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-semibold)',
      fontSize: 'var(--fs-small)',
      color: onDark ? 'var(--white)' : 'var(--text-body)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      padding: '13px 22px',
      background: onDark ? 'rgba(255,255,255,.10)' : 'var(--white)',
      border: `1.5px solid ${error ? '#B3391B' : focus ? 'var(--ih-green)' : onDark ? 'var(--border-inverse)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-input)',
      boxShadow: focus ? 'var(--ring-focus)' : 'none',
      transition: 'var(--transition-interactive)'
    }
  }, iconLeft ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: 18,
    color: onDark ? 'var(--white)' : 'var(--neutral-500)'
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false)
  }, rest, {
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-body)',
      color: onDark ? 'var(--white)' : 'var(--text-body)',
      ...style
    }
  }))), error || hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-small)',
      color: error ? '#B3391B' : onDark ? 'var(--text-on-dark-muted)' : 'var(--text-muted)'
    }
  }, error || hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/NewsletterSignup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Footer newsletter capture: a yellow pill with the field inline and a white
 * circular submit button tucked inside the right edge.
 */
function NewsletterSignup({
  eyebrow = 'Stay in touch',
  placeholder = 'Your email',
  onSubmit,
  style,
  ...rest
}) {
  const [value, setValue] = React.useState('');
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("form", _extends({
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
      onSubmit && onSubmit(value);
    }
  }, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      maxWidth: 480,
      ...style
    }
  }), eyebrow ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 'var(--fs-eyebrow)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--white)'
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      background: 'var(--yellow-900)',
      borderRadius: 'var(--radius-pill)',
      padding: '5px 5px 5px 26px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "email",
    required: true,
    value: value,
    placeholder: placeholder,
    onChange: e => {
      setValue(e.target.value);
      setSent(false);
    },
    "aria-label": placeholder,
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 'var(--fs-body)',
      color: 'var(--ih-green)'
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: sent ? 'check' : 'arrow-right',
    label: "Subscribe",
    variant: "onDark",
    size: "sm"
  })), sent ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--yellow-500)',
      fontSize: 'var(--fs-small)'
    }
  }, "Thanks \u2014 you're on the list.") : null);
}
Object.assign(__ds_scope, { NewsletterSignup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/NewsletterSignup.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  options = [],
  value,
  onChange,
  id,
  placeholder,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const selectId = id || `ih-select-${React.useId()}`;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: selectId,
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-semibold)',
      fontSize: 'var(--fs-small)',
      color: 'var(--text-body)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      padding: '13px 20px 13px 22px',
      background: 'var(--white)',
      border: `1.5px solid ${focus ? 'var(--ih-green)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-input)',
      boxShadow: focus ? 'var(--ring-focus)' : 'none',
      transition: 'var(--transition-interactive)'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: selectId,
    value: value,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false)
  }, rest, {
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      appearance: 'none',
      WebkitAppearance: 'none',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-body)',
      cursor: 'pointer',
      ...style
    }
  }), placeholder ? /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder) : null, options.map(o => {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18,
    color: "var(--ih-green)"
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteFooter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SiteFooter({
  columns = [],
  logo,
  logoAlt = 'IH Seeds — Irwin Hunter & Co',
  statement,
  legal,
  onSubscribe,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("footer", _extends({}, rest, {
    style: {
      background: 'var(--surface-inverse)',
      color: 'var(--white)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--space-20) var(--space-10) var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(320px,1fr) auto',
      gap: 'var(--space-16)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.NewsletterSignup, {
    onSubmit: onSubscribe
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-16)',
      flexWrap: 'wrap'
    }
  }, columns.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.title,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 'var(--fs-h6)',
      color: 'var(--white)'
    }
  }, col.title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, col.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l.label
  }, /*#__PURE__*/React.createElement("a", {
    href: l.href || '#',
    style: {
      color: 'var(--text-on-dark-muted)',
      textDecoration: 'none',
      fontSize: 'var(--fs-body)'
    }
  }, l.label)))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.4fr) auto',
      gap: 'var(--space-16)',
      alignItems: 'end',
      marginTop: 'var(--space-24)'
    }
  }, statement ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--white)',
      fontWeight: 'var(--fw-light)',
      fontSize: 'clamp(1.5rem,2.6vw,2.5rem)',
      lineHeight: 1.25,
      maxWidth: '30ch'
    }
  }, statement) : /*#__PURE__*/React.createElement("span", null), logo ? /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: logoAlt,
    style: {
      height: 132,
      width: 'auto',
      justifySelf: 'end'
    }
  }) : null), legal ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-12)',
      paddingTop: 'var(--space-6)',
      borderTop: '1px solid var(--border-inverse)',
      display: 'flex',
      gap: 'var(--space-6)',
      flexWrap: 'wrap',
      fontSize: 'var(--fs-small)',
      color: 'var(--text-on-dark-muted)'
    }
  }, legal) : null));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IH Seeds site header. Transparent and white-on-photography when overlaying a hero;
 * solid white with green links otherwise.
 */
function SiteHeader({
  logo,
  logoAlt = 'IH Seeds — Irwin Hunter & Co',
  items = [],
  activeItem,
  onNavigate,
  cta = 'Get in Touch',
  ctaHref,
  utilities = ['search', 'user', 'shopping-bag'],
  tone = 'onImage',
  sticky = false,
  style,
  ...rest
}) {
  const onImage = tone === 'onImage';
  const linkColor = onImage ? 'var(--white)' : 'var(--ih-green)';
  return /*#__PURE__*/React.createElement("header", _extends({}, rest, {
    style: {
      position: sticky ? 'sticky' : 'relative',
      top: sticky ? 0 : undefined,
      zIndex: 20,
      background: onImage ? 'transparent' : 'var(--white)',
      borderBottom: onImage ? '1px solid transparent' : '1px solid var(--border-subtle)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--space-6) var(--space-10)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate('home');
    },
    style: {
      flex: '0 0 auto',
      lineHeight: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: logoAlt,
    style: {
      height: 92,
      width: 'auto'
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)',
      marginLeft: 'auto'
    }
  }, items.map(it => {
    const key = it.id || it.label;
    const active = activeItem === key;
    return /*#__PURE__*/React.createElement("a", {
      key: key,
      href: it.href || '#',
      onClick: e => {
        if (onNavigate) {
          e.preventDefault();
          onNavigate(key);
        }
      },
      style: {
        fontFamily: 'var(--font-brand)',
        fontWeight: 'var(--fw-semibold)',
        fontSize: 'var(--fs-h6)',
        color: linkColor,
        textDecoration: 'none',
        paddingBottom: 3,
        borderBottom: `2px solid ${active ? 'var(--yellow-900)' : 'transparent'}`,
        transition: 'var(--transition-interactive)',
        whiteSpace: 'nowrap'
      }
    }, it.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      flex: '0 0 auto'
    }
  }, cta ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "accent",
    href: ctaHref,
    onClick: e => {
      if (onNavigate && !ctaHref) {
        e.preventDefault();
        onNavigate('contact');
      }
    }
  }, cta) : null, utilities.map(u => /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    key: u,
    icon: u,
    label: u,
    size: "sm",
    variant: onImage ? 'quiet' : 'ghost',
    style: onImage ? undefined : {
      color: 'var(--ih-green)'
    }
  })))));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// components/product/QuickFacts.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Product-page quick-facts bar: rainfall, soil pH, sowing rate, sowing/heading timing.
 */
function QuickFacts({
  items = [],
  tone = 'subtle',
  style,
  ...rest
}) {
  const onDark = tone === 'green';
  return /*#__PURE__*/React.createElement("dl", _extends({}, rest, {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${Math.min(items.length || 1, 4)},minmax(0,1fr))`,
      gap: 'var(--space-6)',
      margin: 0,
      padding: 'var(--space-6) var(--space-8)',
      background: onDark ? 'var(--surface-inverse)' : 'var(--surface-subtle)',
      borderRadius: 'var(--radius-card)',
      ...style
    }
  }), items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.label,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start'
    }
  }, it.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon,
    size: 20,
    color: onDark ? 'var(--yellow-900)' : 'var(--ih-green)',
    style: {
      marginTop: 2
    }
  }) : null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", {
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 'var(--fs-eyebrow)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: onDark ? 'var(--text-on-dark-muted)' : 'var(--text-muted)',
      marginBottom: 4
    }
  }, it.label), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-semibold)',
      fontSize: 'var(--fs-h6)',
      color: onDark ? 'var(--white)' : 'var(--text-heading)'
    }
  }, it.value)))));
}
Object.assign(__ds_scope, { QuickFacts });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/QuickFacts.jsx", error: String((e && e.message) || e) }); }

// components/product/StockPill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STATES = {
  'in-stock': {
    label: 'Good stock',
    bg: 'var(--status-in-stock-bg)',
    fg: 'var(--status-in-stock-fg)',
    dot: 'var(--ih-green)'
  },
  'low': {
    label: 'Low stock',
    bg: 'var(--status-low-bg)',
    fg: 'var(--status-low-fg)',
    dot: 'var(--yellow-900)'
  },
  'very-low': {
    label: 'Very low',
    bg: 'var(--status-low-bg)',
    fg: 'var(--status-low-fg)',
    dot: 'var(--yellow-900)'
  },
  'unavailable': {
    label: 'Unavailable',
    bg: 'var(--status-out-bg)',
    fg: 'var(--status-out-fg)',
    dot: 'var(--neutral-200)'
  }
};
function StockPill({
  status = 'in-stock',
  label,
  size = 'md',
  style,
  ...rest
}) {
  const s = STATES[status] || STATES['in-stock'];
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      padding: sm ? '4px 12px 4px 10px' : '7px 16px 7px 13px',
      borderRadius: 'var(--radius-badge)',
      background: s.bg,
      color: s.fg,
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: sm ? '0.75rem' : 'var(--fs-small)',
      lineHeight: 1.2,
      whiteSpace: 'nowrap',
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: s.dot,
      flex: '0 0 auto'
    }
  }), label || s.label);
}
Object.assign(__ds_scope, { StockPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/StockPill.jsx", error: String((e && e.message) || e) }); }

// components/product/ProductCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ProductCard({
  name,
  price,
  image,
  category,
  packSize,
  status,
  href,
  onClick,
  imageHeight = 300,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: onClick,
    style: {
      position: 'relative',
      display: 'block',
      overflow: 'hidden',
      borderRadius: 'var(--radius-image)',
      height: imageHeight,
      background: 'var(--green-050)',
      boxShadow: 'var(--shadow-image)',
      textDecoration: 'none'
    }
  }, image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      transform: hover ? 'scale(1.04)' : 'scale(1)',
      transition: `transform var(--dur-image) var(--ease-standard)`
    }
  }) : null, status ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 'var(--space-4)',
      right: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StockPill, {
    status: status,
    size: "sm"
  })) : null, category ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 'var(--space-4)',
      left: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "accent",
    size: "sm"
  }, category)) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-h5)',
      lineHeight: 1.35,
      fontWeight: 'var(--fw-bold)',
      color: 'var(--text-heading)'
    }
  }, name), price ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--ih-green)',
      fontSize: 'var(--fs-body)'
    }
  }, price) : null, packSize ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-muted)',
      fontSize: 'var(--fs-small)'
    }
  }, packSize) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "arrow-right",
    label: `View ${name}`,
    variant: "accent",
    size: "sm",
    href: href,
    onClick: onClick
  })));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/product/ProductCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/AboutScreen.jsx
try { (() => {
const {
  HeroBanner,
  FeaturePanel,
  Card,
  Icon,
  Button,
  CtaBanner
} = window.IHSeedsDesignSystem_515a16;
function AboutScreen({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(HeroBanner, {
    height: 480,
    align: "center",
    lineOne: "Our",
    lineTwo: "Story",
    lead: "Western Australian owned and operated since 1966.",
    image: "../../assets/img-paddock-02.jpeg"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--section-y) var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-8)',
      marginBottom: 'var(--section-y-tight)'
    }
  }, [{
    k: '60 years',
    v: 'In market — family owned and operated since 1966.'
  }, {
    k: 'Esperance to Derby',
    v: 'Seed distribution network spanning the state.'
  }, {
    k: '113 lines',
    v: 'Species, cultivars and mixes across nine categories.'
  }].map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.k,
    tone: "subtle",
    padding: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 'var(--fs-h3)',
      color: 'var(--ih-green)',
      marginBottom: 'var(--space-3)'
    }
  }, s.k), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, s.v)))), /*#__PURE__*/React.createElement(FeaturePanel, {
    imageSide: "right",
    light: "How we",
    bold: "Work",
    image: "../../assets/img-paddock-03.jpeg",
    body: "We source, test and supply the right species for every region. Custom mix design is informed by your on-farm conditions, and performance is validated through customer trials and on-farm results \u2014 then fed back into next season's recommendations.",
    cta: "Talk to our team",
    onCtaClick: e => {
      e.preventDefault();
      onNavigate('home');
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--space-10) var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement(CtaBanner, {
    tone: "green",
    height: 340,
    headline: "Know your seed. IH Seeds is a member of the Australian Seed Federation.",
    cta: "Get in Touch"
  })));
}
Object.assign(window, {
  AboutScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/AboutScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  HeroBanner,
  Button,
  SectionHeading,
  IconButton,
  ProductCard,
  ArticleCard,
  FeaturePanel,
  CtaBanner,
  Card,
  Icon
} = window.IHSeedsDesignSystem_515a16;
function HomeScreen({
  onNavigate
}) {
  const D = window.IHS_DATA;
  const [offset, setOffset] = React.useState(0);
  const best = D.products.slice(offset, offset + 4);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(HeroBanner, {
    height: 760,
    lineOne: "The Western Australian",
    lineTwo: "Seed Experts",
    lead: "IH Seeds is an independently owned Western Australian company supplying quality pasture seed across the state, from Esperance to Derby. We work with producers and rural retailers to provide seed mixes that perform in local conditions.",
    image: "../../assets/img-paddock-01.jpeg",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => onNavigate('resources')
    }, "Advice"), /*#__PURE__*/React.createElement(Button, {
      variant: "onImage"
    }, "Subscribe to our Newsletter"))
  }), /*#__PURE__*/React.createElement(Section, {
    tone: "subtle",
    wide: true
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    light: "Best",
    bold: "Sellers",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
      icon: "arrow-left",
      label: "Previous",
      variant: "outline",
      disabled: offset === 0,
      onClick: () => setOffset(Math.max(0, offset - 1))
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "arrow-right",
      label: "Next",
      variant: "outline",
      disabled: offset + 4 >= D.products.length,
      onClick: () => setOffset(offset + 1)
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,minmax(0,1fr))',
      gap: 'var(--space-8)'
    }
  }, best.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.name,
    name: p.name,
    price: p.price,
    image: p.image,
    status: p.status,
    onClick: e => {
      e.preventDefault();
      onNavigate('product');
    },
    href: "#"
  })))), /*#__PURE__*/React.createElement(Section, {
    wide: true
  }, /*#__PURE__*/React.createElement(FeaturePanel, {
    light: "About",
    bold: "Us",
    image: "../../assets/img-paddock-04.jpeg",
    body: "Independently owned and operated since 1966, IH Seeds supplies high-quality pasture varieties across Western Australia \u2014 from Esperance in the south to Derby in the north. We continue the IH Seeds tradition of supplying Western Australia with proven pasture seed and practical support. Our mission is to source, test, and supply the right species for every region, working with farmers to achieve consistent, productive pasture performance year after year.",
    cta: "Learn more about IH Seeds",
    onCtaClick: e => {
      e.preventDefault();
      onNavigate('about');
    }
  })), /*#__PURE__*/React.createElement(Section, {
    tone: "subtle",
    tight: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-8)'
    }
  }, [{
    icon: 'map-pin',
    h: 'Regional Expertise',
    p: 'Local conditions, understood and applied. Our long history across Western Australia means we know which varieties and mixes perform best in every region.'
  }, {
    icon: 'sprout',
    h: 'Proven Performance',
    p: 'Improved pasture seed from credible growers ensures genetic integrity and consistent results across every line.'
  }, {
    icon: 'users',
    h: 'Partnership',
    p: 'Confidence before the order. Support after it. We combine local experience with knowledge shared by farmers to provide sound technical advice.'
  }].map(c => /*#__PURE__*/React.createElement(Card, {
    key: c.h,
    tone: "white",
    padding: "md"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: c.icon,
    size: 28,
    color: "var(--ih-green)"
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--fs-h4)',
      marginTop: 'var(--space-5)',
      marginBottom: 'var(--space-3)'
    }
  }, c.h), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-body)'
    }
  }, c.p))))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement(SectionHeading, {
    light: "Tips &",
    bold: "Advice",
    align: "center"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-8)'
    }
  }, D.articles.map(a => /*#__PURE__*/React.createElement(ArticleCard, _extends({
    key: a.title
  }, a, {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate('resources');
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      marginTop: 'var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => onNavigate('resources')
  }, "View More"))), /*#__PURE__*/React.createElement(Section, {
    wide: true,
    tight: true
  }, /*#__PURE__*/React.createElement(CtaBanner, {
    image: "../../assets/img-paddock-05.jpeg",
    headline: "Access the latest IH Seeds Pasture Seed Guide for regional advice, sowing rates, and seasonal planning.",
    cta: "Download the 2026 Pasture Seed Guide (PDF)",
    onCtaClick: e => {
      e.preventDefault();
      onNavigate('resources');
    }
  })));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProductScreen.jsx
try { (() => {
const {
  Button,
  Badge,
  StockPill,
  QuickFacts,
  ProductCard,
  Card,
  Icon
} = window.IHSeedsDesignSystem_515a16;
function ProductScreen({
  onNavigate
}) {
  const D = window.IHS_DATA;
  const p = D.products[0];
  const [shot, setShot] = React.useState(0);
  const gallery = ['../../assets/img-paddock-01.jpeg', '../../assets/img-paddock-03.jpeg', '../../assets/img-paddock-04.jpeg'];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--space-12) var(--space-10) var(--space-6)',
      fontSize: 'var(--fs-small)',
      color: 'var(--text-muted)',
      display: 'flex',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate('home');
    }
  }, "Home"), /*#__PURE__*/React.createElement("span", null, "/"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate('products');
    }
  }, "Products"), /*#__PURE__*/React.createElement("span", null, "/"), /*#__PURE__*/React.createElement("span", null, p.category), /*#__PURE__*/React.createElement("span", null, "/"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-body)'
    }
  }, p.name)), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: '0 var(--space-10) var(--section-y)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.05fr) minmax(0,1fr)',
      gap: 'var(--space-16)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: gallery[shot],
    alt: p.name,
    style: {
      width: '100%',
      height: 460,
      objectFit: 'cover',
      borderRadius: 'var(--radius-image)',
      boxShadow: 'var(--shadow-image)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, gallery.map((g, i) => /*#__PURE__*/React.createElement("button", {
    key: g,
    onClick: () => setShot(i),
    style: {
      padding: 0,
      border: i === shot ? '2px solid var(--ih-green)' : '2px solid transparent',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      cursor: 'pointer',
      background: 'none',
      lineHeight: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: g,
    alt: "",
    style: {
      width: 104,
      height: 74,
      objectFit: 'cover'
    }
  }))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'center',
      flexWrap: 'wrap',
      marginBottom: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "soft",
    uppercase: false
  }, p.category), p.apps.map(a => /*#__PURE__*/React.createElement(Badge, {
    key: a,
    tone: "outline",
    uppercase: false
  }, a)), /*#__PURE__*/React.createElement(StockPill, {
    status: p.status
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, p.name), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-lead)',
      color: 'var(--ih-green)',
      marginBottom: 'var(--space-8)'
    }
  }, p.price, " \xB7 ", p.pack), /*#__PURE__*/React.createElement(QuickFacts, {
    style: {
      marginBottom: 'var(--space-8)'
    },
    items: [{
      label: 'Rainfall',
      value: '450–650 mm',
      icon: 'cloud-rain'
    }, {
      label: 'Soil pH',
      value: '5.0–7.5',
      icon: 'flask-conical'
    }, {
      label: 'Sowing rate',
      value: '20–25 kg/ha',
      icon: 'sprout'
    }, {
      label: 'Sowing window',
      value: 'Apr – Jun',
      icon: 'calendar'
    }]
  }), /*#__PURE__*/React.createElement("h4", null, "Key features"), /*#__PURE__*/React.createElement("p", null, "A balanced perennial mix built for the south-west high-rainfall zone. Establishes quickly, holds density through summer and regenerates reliably from the clover component. Suits set-stocked sheep and rotational cattle grazing alike."), /*#__PURE__*/React.createElement("h4", {
    style: {
      marginTop: 'var(--space-8)'
    }
  }, "What's in the mix"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: '0 0 var(--space-8)',
      padding: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, [['Teff Grass', 'Fast summer bulk in the establishment year.'], ['Prairie Grass', 'Winter-active, high quality feed.'], ['Serradella', 'Deep-rooted legume for acid sands.'], ['Tall Fescue', 'Summer persistence and root depth.'], ['Finecut Rhodes Grass', 'Warm-season ground cover.'], ['Cocksfoot', 'Long-term perennial backbone.']].map(([n, note]) => /*#__PURE__*/React.createElement("li", {
    key: n,
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sprout",
    size: 18,
    color: "var(--ih-green)",
    style: {
      marginTop: 3
    }
  }), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--ih-green)'
    }
  }, n), " \u2014 ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-body)'
    }
  }, note))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 18
    })
  }, "Download the Tech Sheet"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: () => onNavigate('resources')
  }, "View in Tech Sheets Hub")))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--section-y-tight) var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontWeight: 'var(--fw-light)',
      marginBottom: 'var(--space-10)'
    }
  }, "Related ", /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 'var(--fw-bold)'
    }
  }, "Products")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,minmax(0,1fr))',
      gap: 'var(--space-8)'
    }
  }, D.products.slice(1, 5).map(r => /*#__PURE__*/React.createElement(ProductCard, {
    key: r.name,
    name: r.name,
    price: r.price,
    image: r.image,
    status: r.status,
    imageHeight: 220,
    href: "#",
    onClick: e => e.preventDefault()
  }))))));
}
Object.assign(window, {
  ProductScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProductScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProductsScreen.jsx
try { (() => {
const {
  Button,
  Input,
  Checkbox,
  ProductCard,
  StockPill,
  Badge,
  Icon
} = window.IHSeedsDesignSystem_515a16;
function ProductsScreen({
  onNavigate
}) {
  const D = window.IHS_DATA;
  const [cats, setCats] = React.useState([]);
  const [apps, setApps] = React.useState([]);
  const [inStockOnly, setInStockOnly] = React.useState(false);
  const [q, setQ] = React.useState('');
  const toggle = (list, set, v) => set(list.includes(v) ? list.filter(x => x !== v) : [...list, v]);
  const results = D.products.filter(p => (!cats.length || cats.includes(p.category)) && (!apps.length || p.apps.some(a => apps.includes(a))) && (!inStockOnly || p.status === 'in-stock') && (!q || p.name.toLowerCase().includes(q.toLowerCase())));
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--space-16) var(--space-10)',
      display: 'flex',
      gap: 'var(--space-12)',
      alignItems: 'flex-end',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 520px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 'var(--fw-light)',
      marginBottom: 'var(--space-4)'
    }
  }, "Our ", /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 'var(--fw-bold)'
    }
  }, "Products")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-lead)',
      lineHeight: 'var(--lh-lead)',
      color: 'var(--ih-green)'
    }
  }, "Every IH Seeds line and mix in one catalogue, with live availability. Filter by species, livestock or stock status.")), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 18
    }),
    onClick: () => onNavigate('resources')
  }, "Download the 2026 Pasture Seed Guide (PDF)"))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--space-16) var(--space-10)',
      display: 'grid',
      gridTemplateColumns: '280px minmax(0,1fr)',
      gap: 'var(--space-16)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-10)',
      position: 'sticky',
      top: 130
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", {
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, "Category"), D.categories.map(c => /*#__PURE__*/React.createElement(Checkbox, {
    key: c.label,
    label: c.label,
    count: c.count,
    checked: cats.includes(c.label),
    onChange: () => toggle(cats, setCats, c.label)
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", {
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, "Application"), D.applications.map(a => /*#__PURE__*/React.createElement(Checkbox, {
    key: a,
    label: a,
    checked: apps.includes(a),
    onChange: () => toggle(apps, setApps, a)
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", {
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, "Availability"), /*#__PURE__*/React.createElement(Checkbox, {
    label: "In stock only",
    checked: inStockOnly,
    onChange: () => setInStockOnly(!inStockOnly)
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => {
      setCats([]);
      setApps([]);
      setInStockOnly(false);
      setQ('');
    }
  }, "Reset filters")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      alignItems: 'center',
      marginBottom: 'var(--space-8)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Search by product name or SKU",
    iconLeft: "search",
    value: q,
    onChange: e => setQ(e.target.value),
    wrapperStyle: {
      flex: '1 1 320px'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 'var(--fs-small)'
    }
  }, results.length, " of ", D.products.length, " products")), cats.length || apps.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      flexWrap: 'wrap',
      marginBottom: 'var(--space-8)'
    }
  }, [...cats, ...apps].map(t => /*#__PURE__*/React.createElement(Badge, {
    key: t,
    tone: "soft",
    uppercase: false
  }, t))) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-8)'
    }
  }, results.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.name,
    name: p.name,
    price: p.price,
    packSize: p.pack,
    image: p.image,
    status: p.status,
    category: p.category,
    imageHeight: 240,
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate('product');
    }
  }))), !results.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-16)',
      textAlign: 'center',
      color: 'var(--text-muted)'
    }
  }, "Nothing matches those filters. ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setCats([]);
      setApps([]);
      setInStockOnly(false);
      setQ('');
    }
  }, "Reset"), " and try again.") : null)));
}
Object.assign(window, {
  ProductsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProductsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ResourcesScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Button,
  Select,
  Input,
  Card,
  Badge,
  ArticleCard,
  Icon,
  IconButton
} = window.IHSeedsDesignSystem_515a16;
function ResourcesScreen({
  onNavigate
}) {
  const D = window.IHS_DATA;
  const [cat, setCat] = React.useState('');
  const [q, setQ] = React.useState('');
  const sheets = D.techSheets.filter(s => (!cat || s.category === cat) && (!q || s.name.toLowerCase().includes(q.toLowerCase())));
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--space-16) var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 'var(--fw-light)',
      marginBottom: 'var(--space-4)'
    }
  }, "Tech ", /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 'var(--fw-bold)'
    }
  }, "Sheets Hub")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-lead)',
      lineHeight: 'var(--lh-lead)',
      color: 'var(--ih-green)',
      maxWidth: 'var(--measure-lead)'
    }
  }, "Every IH Seeds tech sheet and guide in one place. Filter by category, or search by product name."))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--section-y-tight) var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      marginBottom: 'var(--space-8)'
    }
  }, "Flagship guides"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-8)',
      marginBottom: 'var(--section-y-tight)'
    }
  }, D.guides.map((g, i) => /*#__PURE__*/React.createElement(Card, {
    key: g.title,
    tone: i === 0 ? 'green' : 'cream',
    padding: "md"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "book-open",
    size: 26,
    color: i === 0 ? 'var(--yellow-900)' : 'var(--ih-green)'
  }), /*#__PURE__*/React.createElement("h4", {
    style: {
      marginTop: 'var(--space-5)',
      marginBottom: 'var(--space-3)',
      color: i === 0 ? 'var(--white)' : 'var(--text-heading)'
    }
  }, g.title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: i === 0 ? 'var(--text-on-dark-muted)' : 'var(--text-body)'
    }
  }, g.note), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: i === 0 ? 'accent' : 'primary',
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 16
    })
  }, "Download"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-small)',
      color: i === 0 ? 'var(--text-on-dark-muted)' : 'var(--text-muted)'
    }
  }, g.size))))), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginBottom: 'var(--space-6)'
    }
  }, "Product tech sheets"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      flexWrap: 'wrap',
      marginBottom: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    placeholder: "All product types",
    value: cat,
    onChange: e => setCat(e.target.value),
    options: [...new Set(D.techSheets.map(s => s.category))],
    wrapperStyle: {
      flex: '0 1 260px'
    }
  }), /*#__PURE__*/React.createElement(Input, {
    placeholder: "Search tech sheets",
    iconLeft: "search",
    value: q,
    onChange: e => setQ(e.target.value),
    wrapperStyle: {
      flex: '1 1 280px'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden'
    }
  }, sheets.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.name,
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.1fr) 180px minmax(0,1.4fr) auto',
      gap: 'var(--space-6)',
      alignItems: 'center',
      padding: 'var(--space-5) var(--space-6)',
      borderTop: i ? '1px solid var(--border-subtle)' : 'none',
      background: i % 2 ? 'var(--surface-subtle)' : 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--fw-bold)',
      color: 'var(--ih-green)'
    }
  }, s.name), /*#__PURE__*/React.createElement(Badge, {
    tone: "soft",
    uppercase: false
  }, s.category), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 'var(--fs-small)'
    }
  }, s.note), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 16
    })
  }, "Tech Sheet"))), !sheets.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-10)',
      textAlign: 'center',
      color: 'var(--text-muted)'
    }
  }, "No tech sheets match that filter.") : null)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-content)',
      margin: '0 auto',
      padding: 'var(--section-y-tight) var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 'var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontWeight: 'var(--fw-light)'
    }
  }, "From the ", /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 'var(--fw-bold)'
    }
  }, "Paddock")), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: () => onNavigate('home')
  }, "All articles")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-8)'
    }
  }, D.articles.map(a => /*#__PURE__*/React.createElement(ArticleCard, _extends({
    key: a.title
  }, a, {
    imageHeight: 220,
    href: "#",
    onClick: e => e.preventDefault()
  })))))));
}
Object.assign(window, {
  ResourcesScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ResourcesScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Shell.jsx
try { (() => {
const {
  SiteHeader,
  SiteFooter
} = window.IHSeedsDesignSystem_515a16;
function Shell({
  page,
  onNavigate,
  children
}) {
  const solid = page !== 'home';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: solid ? undefined : {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 30
    }
  }, /*#__PURE__*/React.createElement(SiteHeader, {
    tone: solid ? 'solid' : 'onImage',
    sticky: solid,
    logo: solid ? '../../assets/logo-ihseeds-irwinhunter-colour.png' : '../../assets/logo-mono-white.png',
    items: window.IHS_DATA.nav,
    activeItem: page,
    onNavigate: onNavigate
  })), /*#__PURE__*/React.createElement("main", null, children), /*#__PURE__*/React.createElement(SiteFooter, {
    logo: "../../assets/logo-ihseeds-white.png",
    statement: "The pasture seed and mixes specialists of Western Australia.",
    columns: [{
      title: 'Products',
      links: [{
        label: 'Specialty Mixes'
      }, {
        label: 'Ryegrass'
      }, {
        label: 'Clovers'
      }, {
        label: 'Lucerne'
      }]
    }, {
      title: 'Resources',
      links: [{
        label: 'Tech Sheets Hub'
      }, {
        label: 'Pasture Seed Guide'
      }, {
        label: 'From the Paddock'
      }]
    }, {
      title: 'Company',
      links: [{
        label: 'Our Story'
      }, {
        label: 'Stockists'
      }, {
        label: 'Contact'
      }]
    }],
    legal: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Irwin Hunter & Co"), /*#__PURE__*/React.createElement("span", null, "Australian Seed Federation member"), /*#__PURE__*/React.createElement("span", null, "Privacy"), /*#__PURE__*/React.createElement("span", null, "Terms"))
  }));
}
function Section({
  children,
  tone = 'white',
  tight = false,
  wide = false,
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: tone === 'subtle' ? 'var(--surface-subtle)' : tone === 'cream' ? 'var(--surface-cream)' : 'var(--white)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: wide ? 'var(--container-max)' : 'var(--container-content)',
      margin: '0 auto',
      padding: `${tight ? 'var(--section-y-tight)' : 'var(--section-y)'} var(--space-10)`
    }
  }, children));
}
Object.assign(window, {
  Shell,
  Section
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
window.IHS_DATA = {
  nav: [{
    id: 'products',
    label: 'Products'
  }, {
    id: 'guide',
    label: 'Seed Guide 2026'
  }, {
    id: 'availability',
    label: 'Seed Availability'
  }, {
    id: 'resources',
    label: 'Resources'
  }, {
    id: 'about',
    label: 'About'
  }],
  categories: [{
    label: 'Specialty Mixes',
    count: 14
  }, {
    label: 'Ryegrass',
    count: 14
  }, {
    label: 'Clovers',
    count: 11
  }, {
    label: 'Lucerne',
    count: 3
  }, {
    label: 'Other Grasses',
    count: 7
  }, {
    label: 'Alternative Crops',
    count: 10
  }, {
    label: 'Serradella & Medic',
    count: 4
  }, {
    label: 'Sub-Tropical',
    count: 6
  }, {
    label: 'Bio Stimulants',
    count: 1
  }],
  applications: ['Cattle', 'Sheep', 'Dairy', 'Horses', 'Mixed'],
  products: [{
    name: 'SouWest™ Pasture Mix',
    category: 'Specialty Mixes',
    apps: ['Sheep', 'Cattle'],
    price: '$25.00 per kg',
    pack: '25 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-01.jpeg'
  }, {
    name: 'Maximix',
    category: 'Specialty Mixes',
    apps: ['Cattle', 'Mixed'],
    price: '$25.00 per kg',
    pack: '25 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-02.jpeg'
  }, {
    name: 'Silahay™ Mix',
    category: 'Specialty Mixes',
    apps: ['Dairy'],
    price: '$25.00 per kg',
    pack: '25 kg bag',
    status: 'low',
    image: '../../assets/img-paddock-03.jpeg'
  }, {
    name: 'Self Regeneration Pasture Mix',
    category: 'Specialty Mixes',
    apps: ['Sheep'],
    price: '$25.00 per kg',
    pack: '25 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-04.jpeg'
  }, {
    name: 'Equi1st Mix',
    category: 'Specialty Mixes',
    apps: ['Horses'],
    price: '$28.00 per kg',
    pack: '20 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-05.jpeg'
  }, {
    name: 'Safeguard Tetraploid',
    category: 'Ryegrass',
    apps: ['Dairy', 'Cattle'],
    price: '$9.50 per kg',
    pack: '25 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-02.jpeg'
  }, {
    name: 'Ceres PG One50',
    category: 'Ryegrass',
    apps: ['Dairy'],
    price: '$11.20 per kg',
    pack: '25 kg bag',
    status: 'very-low',
    image: '../../assets/img-paddock-01.jpeg'
  }, {
    name: 'Coolamon Sub Clover',
    category: 'Clovers',
    apps: ['Sheep', 'Cattle'],
    price: '$13.40 per kg',
    pack: '25 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-03.jpeg'
  }, {
    name: 'Paradana Balansa',
    category: 'Clovers',
    apps: ['Sheep'],
    price: '$14.10 per kg',
    pack: '25 kg bag',
    status: 'unavailable',
    image: '../../assets/img-paddock-05.jpeg'
  }, {
    name: 'Sceptre Lucerne',
    category: 'Lucerne',
    apps: ['Dairy', 'Cattle'],
    price: '$16.80 per kg',
    pack: '25 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-04.jpeg'
  }, {
    name: 'Katambora Rhodes Grass',
    category: 'Sub-Tropical',
    apps: ['Cattle'],
    price: '$12.00 per kg',
    pack: '20 kg bag',
    status: 'low',
    image: '../../assets/img-paddock-02.jpeg'
  }, {
    name: 'Tonic Plantain',
    category: 'Alternative Crops',
    apps: ['Sheep', 'Dairy'],
    price: '$21.00 per kg',
    pack: '10 kg bag',
    status: 'in-stock',
    image: '../../assets/img-paddock-01.jpeg'
  }],
  articles: [{
    date: '27 October 2025',
    title: 'Mix & Match Custom Pasture',
    excerpt: "The need for sustainable and productive pastures has never been greater in today's farming landscape. With increasing interest in regenerative agriculture, farmers seek ways to improve soil health, boost yields, and maximise grazing efficiency.",
    image: '../../assets/img-paddock-03.jpeg',
    category: 'Editorial'
  }, {
    date: '12 September 2025',
    title: 'Getting Your Autumn Sowing Window Right',
    excerpt: 'Timing decides the season. We look at soil temperature, rainfall triggers and the sowing rates that hold up across the WA wheatbelt.',
    image: '../../assets/img-paddock-05.jpeg',
    category: 'Sowing & Timing'
  }, {
    date: '4 August 2025',
    title: 'Feed Planning Through a Dry Finish',
    excerpt: 'Practical steps for holding feed quality when the season shortens — species selection, grazing rotation and the mixes that recover fastest.',
    image: '../../assets/img-paddock-02.jpeg',
    category: 'Feed Planning'
  }],
  techSheets: [{
    name: 'SouWest™ Pasture Mix',
    category: 'Specialty Mixes',
    note: 'Balanced perennial mix for the south-west high-rainfall zone.'
  }, {
    name: 'Silahay™ Mix',
    category: 'Specialty Mixes',
    note: 'Silage and hay mix built for bulk early feed.'
  }, {
    name: 'Safeguard Tetraploid',
    category: 'Ryegrass',
    note: 'Annual tetraploid ryegrass with rapid winter growth.'
  }, {
    name: 'Ceres PG One50',
    category: 'Ryegrass',
    note: 'Perennial ryegrass for persistent dairy pasture.'
  }, {
    name: 'Coolamon Sub Clover',
    category: 'Clovers',
    note: 'Mid-season subterranean clover with strong regeneration.'
  }, {
    name: 'Sceptre Lucerne',
    category: 'Lucerne',
    note: 'Winter-active lucerne for hay and grazing rotations.'
  }, {
    name: 'Katambora Rhodes Grass',
    category: 'Sub-Tropical',
    note: 'Sub-tropical perennial for northern pastoral country.'
  }, {
    name: 'Tonic Plantain',
    category: 'Alternative Crops',
    note: 'High-mineral herb for lamb finishing and dairy.'
  }],
  guides: [{
    title: '2026 Pasture Seed Guide',
    note: 'The full annual guide — regional advice, sowing rates and seasonal planning.',
    size: 'PDF · 8.4 MB'
  }, {
    title: 'Specialty Mixes Guide',
    note: 'Every IH Seeds mix, its components and where it belongs.',
    size: 'PDF · 2.1 MB'
  }, {
    title: 'Sub-Tropical Species Guide',
    note: 'Northern pastoral species selection and establishment.',
    size: 'PDF · 1.7 MB'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

__ds_ns.ArticleCard = __ds_scope.ArticleCard;

__ds_ns.CtaBanner = __ds_scope.CtaBanner;

__ds_ns.FeaturePanel = __ds_scope.FeaturePanel;

__ds_ns.HeroBanner = __ds_scope.HeroBanner;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.NewsletterSignup = __ds_scope.NewsletterSignup;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.QuickFacts = __ds_scope.QuickFacts;

__ds_ns.StockPill = __ds_scope.StockPill;

})();
