# IH Seeds Design System

**IH Seeds — Irwin Hunter & Co** is a family-owned Western Australian pasture seed company, independently owned and operated since 1966. It sources, tests, blends and supplies improved pasture seed varieties and mixes across WA, from Esperance in the south to Derby in the north, selling mostly *through* rural resellers rather than direct.

**Brand promise:** "The pasture seed and mixes specialists of Western Australia."
**Vision:** where WA's farmers go for high quality, improved pasture seed and sound technical advice.
**Tone of voice (stated):** Direct · Confident · Educational.

**Brand pillars** — Regional Expertise ("Local conditions, understood and applied") · Proven Performance ("Pasture varieties and mixes proven over generations across Australia") · Partnership ("Confidence before the order. Support after it").

**Audiences:** Independent Farmers (35+), Ag Store Managers (35–60, ~70% of sales), Procurement Managers at corporate feedlots and pastoral companies, and hands-on Operations Managers. Copy must satisfy a farmer who wants a quick, confident answer *and* a procurement manager who wants trial data — never at the cost of plain speech.

**Product surface:** ~113 SKUs across Specialty Mixes, Ryegrass, Clovers, Lucerne, Other Grasses, Alternative/Forage Crops, Serradella & Medic, Sub-Tropical Grasses & Legumes, and Bio Stimulants.

---

## Products / surfaces represented

There is **one digital product**: the **marketing website** (public catalogue + Tech Sheets Hub + blog, with a login-gated WordPress-style admin planned but not yet designed). No mobile app, no customer portal, no e-commerce checkout — IH Seeds is informational, with purchase routed through resellers. Accordingly this system ships **one UI kit** (`ui_kits/website/`).

## Sources this system was built from

Everything below was supplied by the user; the reader may not have access, so paths are recorded verbatim.

**Attached local codebase folder: `WEBSITE/`**
- `WEBSITE/BNR/BNR-001 Style Guide/IH_Style Guide_5Nov25_01.pdf` — **the authoritative brand spec.** Colour values (print + web), logo formats, Raleway/Tahoma fonts, Broader Visual Language, button styles with hover/active states, and the full web type scale. Also uploaded to `uploads/IH_Style Guide_5Nov25_01.pdf`.
- `WEBSITE/BNR/BNR-002 Logos/` — logo lockups (colour, stacked, reversed white, mono) + `IHSeeds-Mini Brand Guide.pdf`.
- `WEBSITE/BNR/BNR-003 BVL/{SVG,PNG}/Green.*` — the Broader Visual Language linework pattern.
- `WEBSITE/BNR/BNR-001 Style Guide/Assets/*.jpeg` — five paddock/crop photographs (AI-generated "Whisk_*" files, used in the style guide).
- `WEBSITE/BNR/IHS_Website Home Mockup_23Oct25_01.html` + `_files/` — a **saved Figma player shell only**. Contains no design content. The live prototype is `https://www.figma.com/proto/vcdOqVEuZAVYhzXDM1c1Na/IHS_Home-Mockup_23Oct25_01?page-id=0%3A1&node-id=2-640`.
- `WEBSITE/IH Seeds_Brand Messaging Strategy_19_11_25_V2.pdf` (and the 28 Oct V2 + `.pptx`) — North Star, segmentation, four ICPs, competitive analysis, brand message framework. Source of all real copy in this system.
- `WEBSITE/IH-Seeds-Website-Sitemap-and-Functional-Spec.md` — sitemap, unified catalogue model, product-detail page structure, Tech Sheets Hub spec, admin/CMS spec, competitor findings (Barenbrug, AlfaGen, Valley Seeds, Naracoorte).
- `WEBSITE/IHSEEDS *.docx`, `WEBSITE/IH Seed website updates *.docx` — client Q&A and change logs.
- `WEBSITE/dave porter/*.pdf` — operational docs for the current WordPress site.

**Uploaded screenshots** — six captures of the Figma home mockup (`uploads/Screenshot 2026-08-31 at 3.59.51 pm.png` … `4.00.08 pm.png`): hero, Best Sellers, About Us, Tips & Advice, Seed Guide CTA, footer.

**Live site:** `https://www.irwinhunter.com.au` (referenced by the sitemap; not crawled here).

> ⚠️ **No component source code exists for the IH Seeds website.** The current site is WordPress and was not attached; the "mockup" HTML is a Figma player. The homepage layout in this system is reconstructed from the Style Guide's specified values plus the six prototype screenshots — accurate on colour, type, radii and button states (all specified numerically), close-but-not-exact on spacing and photo crops.

---

## CONTENT FUNDAMENTALS

**Voice:** direct, confident, educational — in that order. Sentences are short and declarative. The brand states a fact and lets it stand; it does not sell hard, and it never hypes.

**Person.** "We" for IH Seeds, "you" for the reader. Never "I". Never third-person self-reference ("IH Seeds believes…") except in the formal positioning statement.
- ✅ "We work with producers and rural retailers to provide seed mixes that perform in local conditions."
- ✅ "Our long history across Western Australia means we know which varieties and mixes perform best in every region."

**Casing.** Sentence case everywhere — headings, buttons, nav. Two exceptions: (1) small eyebrow/label text is UPPERCASE with 0.12em tracking ("STAY IN TOUCH", "RECOMMENDED RAINFALL"); (2) proper nouns and cultivar names keep their real casing (`SouWest™ Pasture Mix`, `Ceres PG One50`, `Silahay™`). Never ALL-CAPS a headline or a button.

**Spelling & units.** Australian English — *maximise, specialise, programme→program (AU tech usage), metre, tonne*. Metric only: mm rainfall, kg/ha sowing rates, kg bags, hectares. Dates written long-form Australian: "27 October 2025", never "10/27/25". Regions named specifically — Esperance, Derby, the south-west, the wheatbelt, "the northern pastoral".

**Sentence rhythm.** The brand's signature is a two-clause line with a full stop in the middle: *"Confidence before the order. Support after it."* · *"Local conditions, understood and applied."* Use it for pillar statements and section subheads.

**Headings** use the two-weight split: light lead + bold noun. "Best **Sellers**" · "Tips & **Advice**" · "About **Us**" · "The Western Australian **Seed Experts**". Split at the natural phrase break, with the noun in bold.

**Buttons** are plain verbs or plainly-named destinations, sentence case, and say exactly what happens — including the file type: "Advice" · "Get in Touch" · "View More" · "Learn more about IH Seeds" · "Download the 2026 Pasture Seed Guide (PDF)" · "Download the Tech Sheet". Never "Click here", "Learn more →" alone, or a bare "Submit".

**Numbers as proof, not decoration.** Only real, checkable claims: *"Western Australian owned and operated since 1966"*, *"60 years in market"*, *"Esperance to Derby"*, *"Australian Seed Federation member"*, *"true to type seed from credible growers"*. Never invent a statistic or a percentage.

**Availability language** mirrors the legacy stock table: **Good stock / Low stock / Very low / Unavailable**. Never "Sold out" or "Out of stock" — resellers hold stock too.

**Emoji: never.** Not in UI, not in editorial, not in the newsletter. No decorative arrows in copy either (the arrow is a component, not a character). Exclamation marks: avoid entirely. Em-dashes are fine; the brand uses them in body prose.

**What to avoid.** Startup register ("revolutionising", "next-gen", "game-changing", "journey", "passionate"), agency filler ("solutions", "innovative", "cutting-edge" unqualified), and anything that talks over a farmer. The competitive analysis explicitly rates rivals' corporate tone as a weakness — sounding corporate is an own-goal for this brand.

---

## VISUAL FOUNDATIONS

**The idea.** "Confident, contemporary… scientific credibility, Australian authenticity, and ease of partnership. Modern enough to signal innovation, agricultural enough to maintain trust" (Messaging Strategy). Visually that lands as: deep pasture green + a single wheat-yellow accent, generous white space, big warm photography, and full-pill geometry.

### Colour
Three brand colours, each with a four-step ramp (see `tokens/colors.css`):
- **Green `#0C583C`** — the brand. Headings, primary buttons, feature panels, footer. Ramp: `#0C583C → #839587 → #C5CCC5 → #EFF1EE`. `--green-050 #EFF1EE` is the workhorse alternating section background.
- **Yellow `#F9B617`** — the *conversion* colour and nothing else. "Get in Touch", guide downloads, product-card arrows, the newsletter pill, the "EDITORIAL" flag, active nav underline. Never a large fill, never body text.
- **Black Green `#1D281C`** — body text and photographic scrims. Ramp used for neutrals and borders. Labelled "minimal use" in the guide; respect that.

Only ever two background colours per page: white and `--green-050`. Green (`--surface-inverse`) and yellow appear as *objects* on those grounds, not as page backgrounds. Palette is warm-neutral; no blue, no purple, no gradient meshes.

**Button colours are specified, not derived** — primary `#09583C` → hover `#06763C` → active `#1E3721`; accent `#F9B617` → hover `#F8D999` → active `#FAC720`. Use the tokens; never darken/lighten programmatically.

### Type
**Raleway** for everything — display, headings and body. Weights in play: Light 300 (display/section lead, large light statements), Regular 400 (body, article headlines), Semibold 600 (nav links, labels), Bold 700 (h1/h2, buttons, product names, eyebrows). **Tahoma** is the guide's nominated system fallback.

Web scale exactly as tabled: h1 48/1.2/700 · h2 36/1.3/700 · h3 30/1.4/600–700 · h4 24/1.4/600 · h5 20/1.5/500–600 · h6 16/1.6/500 · p 16/1.6/400. Hero display runs larger (`--fs-display`, clamped 48–88px) at 1.05 line-height and −0.01em tracking. Prose measure caps at 64ch; hero lead at 52ch. Body copy on green loosens to 1.8 line-height.

### Spacing & layout
4px base scale. Sections are 96px vertical (`--section-y`), 64px when tight. Page gutter 40px; content column 1180px, full-bleed max 1440px. Grid gap 32px. Catalogue is 3-up, best-sellers and related products 4-up, editorial 3-up. **Layouts are flex/grid with `gap` — never margin chains.** The only fixed element is the header (sticky on inner pages; absolutely positioned over the hero on the homepage).

### Corners
The guide says "Full rounded" buttons and "Image Corners Rounded". So: **pill (999px)** for every button, input, badge and pill; **16px** for photographs, product cards and the inset CTA band; **24px** for the large green feature panels; **4px** for checkboxes — the single non-pill control in the system. Nothing is ever a hard square corner except full-bleed photography.

### Cards
Product and article cards are **not boxed**. The photograph is the card: a 16px-radius image with `--shadow-image` (0 2px 10px, 10% black-green), then text sitting directly on the page background below it — no container border, no padding frame. Only *content* cards (stats, quick facts, guide tiles) use a real surface: white or sage fill, 1px `--border-subtle`, 16px radius, `--shadow-card`. No colored left borders, ever.

### Backgrounds, imagery & texture
Photography is the dominant background device: warm, sunlit, low-golden-hour Western Australian farmland — aerial paddock geometry, crop close-ups, seed in a weathered hand. Greens and ochres, warm cast, no grain filter, no black-and-white, no duotone. Full-bleed for heroes; 16px-inset-rounded for CTA bands and cards.

The **Broader Visual Language** (`assets/bvl-linework-green.svg`) is a fine, hand-drawn vertical linework pattern — "cultivated rows and the flow of growth". Use it sparingly as a tonal band, section divider or packaging/print texture at low contrast. Do not put it behind body copy.

Gradients are used for **one purpose only**: the photographic scrim. `--scrim-hero` is a black-green wash (55% → 28% → 45% top-to-bottom); `--scrim-card` fades in from 40% height for text at the bottom of an image. Protection is by **scrim, not capsule** — white type sits straight on the photo through the wash, never in a solid box. Decorative gradients are out of the palette.

### Transparency & blur
Almost none. Transparency appears in the scrim, in `--border-inverse` (white at 28% for footer dividers) and in the `quiet` icon-button hover (white at 16%). **No backdrop blur anywhere** — the header over the hero is fully transparent, relying on the scrim.

### Elevation
Deliberately soft and low-contrast; colour does the separating. `--shadow-image` on photos, `--shadow-card` on content cards, `--shadow-card-hover` (0 8px 24px) on hover, `--shadow-panel` for anything floating. Never a hard or coloured shadow.

### Borders
1px `--border-subtle #EDEDEB` for dividers and table rows; 1.5px `--border-default #C5CCC5` on resting inputs; 2px `--btn-outline-border` on outline buttons; 2px yellow underline for the active nav item. Green 1.5px on focused inputs.

### Motion
Restrained and functional. 120ms fast / 180ms base / 320ms slow, plus 500ms for image scale, all on `cubic-bezier(.2,.6,.2,1)`. Colour and border transitions on every interactive element. Photos scale to 1.04 on card hover. Cards lift −2px. **No bounce, no spring, no parallax, no scroll-triggered reveals, no autoplaying carousels** — the carousel arrows are manual. Fades are for state changes only, never for entrance choreography.

### States
- **Hover:** buttons move to their specified hover colour (primary goes *lighter/brighter* green `#06763C`, accent goes *paler* yellow `#F8D999`); outline/ghost fill with `--green-050`; cards lift 2px and gain a shadow while their photo scales 1.04; links shift to `--text-link-hover`.
- **Active/press:** buttons take the specified active colour and translate down 1px. No scale-down.
- **Focus:** 2px yellow (`--focus-ring`) outline at 2px offset; inputs additionally take a green border plus a soft yellow ring (`--ring-focus`).
- **Disabled:** `--neutral-050` fill, `--neutral-500` text, `not-allowed` cursor, no shadow. Icon buttons drop to 65% opacity.
- **Selected:** yellow underline (nav), green filled checkbox, 2px green border (gallery thumbnail).

---

## ICONOGRAPHY

**The brand ships no icon set.** The Style Guide covers logo, colour, fonts, buttons and the linework pattern only; there is no icon font, no SVG sprite, no PNG icon folder in `WEBSITE/BNR/`, and the Figma prototype was not available as code. The homepage mockup uses a small set of generic thin-stroke line icons (magnifier, person, shopping bag, left/right arrows).

**Substitution — flagged.** This system uses **Lucide** (`lucide-static@0.469.0` via jsDelivr CDN) as the closest match: 24px grid, ~2px uniform stroke, rounded caps, outline-only — visually consistent with the mockup's icons. It is wrapped by `components/icons/Icon.jsx`, which renders the CDN SVG as a CSS mask so glyphs tint with `currentColor`. **If IH Seeds has a licensed icon library, send it and this wrapper can be repointed in one file.**

**Rules.**
- Icons are **outline only**, never filled, never two-tone, never in a coloured circle badge (the yellow circle is `IconButton`, whose *content* is a plain arrow).
- Icons are green (`--ih-green`) on light, white on green, yellow (`--yellow-900`) only when they're the sole accent inside a green panel.
- Sizes: 16px inside small buttons, 18–20px inline and in quick facts, 24–28px as a card lead-in, ~42% of the diameter inside an `IconButton`.
- The **arrow is the brand's one real icon idiom**: `arrow-right` in a yellow circle under every product card, `arrow-left`/`arrow-right` outlined beside a section heading for carousel paging, `arrow-right` in a white circle inside the newsletter pill.
- **No emoji.** No unicode characters standing in as icons (no `→`, `✓`, `★`, `•` as an icon — bullets in prose are fine).
- Do not hand-draw new SVG icons; add a Lucide slug instead.

**Real brand assets in `assets/`** (all copied from the supplied sources — nothing was drawn or generated):

| File | What it is |
|---|---|
| `logo-ihseeds-irwinhunter-colour.png` | Primary lockup, full colour, "IH Seeds / Irwin Hunter & Co" (910×649, transparent) |
| `logo-ihseeds-stacked.png` | "IH Seeds" lockup without the Irwin Hunter & Co line |
| `logo-ihseeds-white.png` | **Reversed lockup** — yellow "IH", white "Seeds" and white "Irwin Hunter & Co". The one to use on green and on photography. (Sourced from `Low res from website/IH white.png`; the file named "IH Seeds Logo white trim Transparent.png" in the supplied logo folder is *white trim*, i.e. still the full-colour lockup, so it is not used here.) |
| `logo-mark-colour.png` | Square colour mark (225×225, favicon/avatar use) |
| `logo-mono-white.png`, `logo-mono-black.png` | Single-colour reproduction, per the guide's "Single colour reproduction" page. `logo-mono-white.png` is the **all-white** lockup used in the site header over photography. |
| `bvl-linework-green.svg`, `bvl-linework-green.png` | Broader Visual Language linework pattern (2500×2887) |
| `img-paddock-01…05.jpeg` | The five Style Guide photographs — aerial paddocks, crop close-ups, seed in hand |

The logo lockup runs ~92px tall in the header and ~132px in the footer; never reproduce it below 64px, never recolour it, never stretch it, never rebuild it in type.

---

## Index

**Root**
- `styles.css` — the single entry point consumers link. `@import` lines only.
- `thumbnail.html` — homepage tile.
- `readme.md` (this file) · `SKILL.md` — Agent Skills wrapper.

**`tokens/`** — `fonts.css` (Raleway via Google Fonts) · `colors.css` · `typography.css` · `spacing.css` · `radius.css` · `elevation.css` · `motion.css` · `base.css` (element resets, link colours).

**`assets/`** — logos, BVL linework, photography (table above).

**`guidelines/`** — 21 foundation specimen cards, grouped in the Design System tab as **Colors** (brand core, primary/secondary/neutral ramps, button states, availability status), **Type** (display, heading scale, body & lead, weights, eyebrow, Tahoma fallback), **Spacing** (scale, in-use, radii, elevation) and **Brand** (logos, BVL, photography, scrim, voice).

**Components** — `window.IHSeedsDesignSystem_515a16.<Name>`; each has a `.d.ts` contract and a `.prompt.md` usage note.

| Group | Components |
|---|---|
| `components/core/` | **Button**, **IconButton**, **Badge**, **SectionHeading**, **Card** |
| `components/forms/` | **Input**, **Select**, **Checkbox**, **NewsletterSignup** |
| `components/product/` | **ProductCard**, **StockPill**, **QuickFacts** |
| `components/content/` | **HeroBanner**, **ArticleCard**, **FeaturePanel**, **CtaBanner** |
| `components/navigation/` | **SiteHeader**, **SiteFooter** |
| `components/icons/` | **Icon** |

**`ui_kits/website/`** — the clickable website recreation: `index.html` (entry) · `Shell.jsx` · `HomeScreen.jsx` · `ProductsScreen.jsx` · `ProductScreen.jsx` · `ResourcesScreen.jsx` · `AboutScreen.jsx` · `data.js` · `README.md`.

### Intentional additions

The brand sources define no component library, so the inventory above was derived from what the Style Guide specifies (Button variants and states, badges, rounded image cards, pill inputs) plus what the Figma home mockup visibly contains (header, hero, section heading with carousel arrows, product card with yellow arrow, editorial card with category flag, green feature panel, photographic CTA band, newsletter pill, footer). Three components go slightly beyond that, and are flagged here:

- **`Icon`** — a wrapper for the substituted Lucide set. Needed because the mockup uses icons but no icon source was supplied.
- **`StockPill`** — the Style Guide has no status component, but Seed Availability ("GOOD STOCK / LOW STOCKS / VERY LOW / UNAVAILABLE") is a first-class concept in the functional spec and the legacy site. Colours are drawn from existing tokens.
- **`QuickFacts`** — the functional spec mandates a rainfall/pH/sowing-rate/timing bar on every product page; no visual design exists for it, so this is a plain token-built interpretation.

No Toast, Avatar, Tabs, Tooltip, Dialog, Accordion or Table component has been invented — nothing in the sources calls for them.
